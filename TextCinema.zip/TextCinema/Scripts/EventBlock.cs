using Godot;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public partial class EventBlock : Button
{
	bool isDragging=false;bool isEntered=false;
	Vector2 initialMousePos=Vector2.Zero;
	float offset=0;
	float ioffset=0;
	float fram=0;
	long ifram=0;
	long uid=0;
	editor.Event _event;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{	uid= (long)GetParent().GetNode<Marker2D>("uid").Position.X;
		foreach (var item in editor.EventStream)
		{
			if (item.uid==uid)
			{
				//select
				_event=item;
			}
		}
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
	}
	void entered(){isEntered=true;} void exited(){isEntered=false;}
	 public override void _UnhandledInput(InputEvent @event)
    {
        if (@event is InputEventMouseMotion mouseMotion)
        {
            if (mouseMotion.ButtonMask == MouseButtonMask.Left&&isEntered&&!editor.rect_selecting)
            {
                if (!isDragging)
                {
                    // Start dragging
					uid = (long)GetParent().GetNode<Marker2D>("uid").Position.X;
					editor.select_event(uid);
                    initialMousePos = mouseMotion.Position;
					//ioffset=_event.posX;
					//ifram=_event.frame_stamp;
                    isDragging = true;
					foreach (editor.Event _e in editor.SelectedEvents)
					{
						_e.Entity.GetChild<Marker2D>(4).Position=new Vector2(_e.posX,_e.frame_stamp);
					}
                }
				float dx=initialMousePos.X-mouseMotion.Position.X;
				float dy=initialMousePos.Y-mouseMotion.Position.Y;
				foreach (editor.Event _e in editor.SelectedEvents)
					{
						_e.posX=(long)(_e.Entity.GetChild<Marker2D>(4).Position.X-dx);
						_e.frame_stamp=(long)(_e.Entity.GetChild<Marker2D>(4).Position.Y-dy/EventPanel.scale);
					}
				//_event.posX=(long)(ioffset-dx);
				//_event.frame_stamp=(long)(ifram-dy);
				//GetParent<Node2D>().Position=GetParent<Node2D>().Position.Y*Vector2.Down+Vector2.Left*offset;
				EventPanel.UpdateStream();
            }
            else
            {
                // Stop dragging
				
                isDragging = false;
            }
        }
    }
	void BtnDown(){
		uid = (long)GetParent().GetNode<Marker2D>("uid").Position.X;
		editor.select_event(uid);
	
	}
}
