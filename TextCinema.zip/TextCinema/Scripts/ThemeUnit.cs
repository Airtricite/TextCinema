using Godot;
using System;

public partial class ThemeUnit : Button
{
	void Select()
	{
		ThemeSelect.selected_tuid=(long)GetNode<Marker2D>("tuid").Position.X;
	}
}
