using Godot;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public partial class ThemeSelect : Window
{
	// Called when the node enters the scene tree for the first time.
	Control prev;
	long tuid_assigner=0;
	Hashtable Themes=new Hashtable();
	public static long selected_tuid=0;
	public override void _Ready()
	{
		prev=GetNode<Control>("Panel/Preview");
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	long assign_tuid()
	{
		tuid_assigner+=1;
		return tuid_assigner;
	}
	public override void _Process(double delta)
	{
	}
	void Open()
	{
		Popup();
	}
	void Upload()
	{
		var file_dialog=GetNode<FileDialog>("Panel/FileDialog");
		file_dialog.Popup();

	}
	void FilesSelected(string[] paths)
	{
		foreach (var path in paths)
		{
			
		
		var ext=path.GetExtension().ToLower();
			
				if(ext==".tscn")
				{
					var list=GetNode<Control>("Panel/Explorer/Scr/VBox");
					var button=(Button)GetNode<Button>("Panel/Explorer/Unit").Duplicate();
					var tuid=assign_tuid();
					var file=Godot.FileAccess.Open(path,Godot.FileAccess.ModeFlags.Read);
					if (file!=null)
					{
						//clear all children
						var custom=ResourceLoader.Load<PackedScene>(paths[0]).Instantiate();
						Control theme=null;
						try
						{
							theme=(Control)custom;
						}
						catch (Exception)
						{
							
						}
						if (theme!=null)
						{
							Themes.Add(tuid,theme);
							button.GetChild<Marker2D>(0).Position=tuid*Vector2.Right;
							list.AddChild(button);
						}
						
					}
				}
				
			
			}
	}
	void Delete()
	{if (!Themes.ContainsKey(selected_tuid))
	{
		return;
	}
		Themes.Remove(selected_tuid);
	}
	void Apply()
	{
		if (Themes.ContainsKey(selected_tuid))
		{
			var uid=(long)GetTree().Root.GetNode<Marker2D>("Editor/PropertyPanel/current_uid").Position.X;
			var _e=editor.EventStream.Where(_e=>_e.uid==uid).First();
			if (_e is editor.GeneralTextEvent)
			{
				((editor.GeneralTextEvent)_e).UIOverride= (Control)Themes[selected_tuid];
			}else if (_e is editor.PlotEvent)
			{
				((editor.PlotEvent)_e).UIOverride=(Control)Themes[selected_tuid];
			}
		}
		Visible=false;
	}
	void Close()
	{
		Visible=false;
	}
}
